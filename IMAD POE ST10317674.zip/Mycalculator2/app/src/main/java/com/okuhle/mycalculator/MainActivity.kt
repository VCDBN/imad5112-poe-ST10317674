package com.okuhle.mycalculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var tvNumbers: TextView

    private val numbers = mutableListOf<Double>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)
        tvNumbers = findViewById(R.id.tvNumbers)
    }

    fun onButtonClick(view: View) {
        val button = view as Button
        val buttonText = button.text.toString()

        when {
            buttonText in arrayOf("Addition", "Subtraction", "Multiplication", "Division") -> {
                performOperation(buttonText)
            }
            buttonText == "Square Root" -> {
                calculateSquareRoot()
            }
            buttonText == "Power" -> {
                calculatePower()
            }
            buttonText == "Clear Array" -> {
                clearArray()
            }
            buttonText == "Average" -> {
                calculateAverage()
            }
            buttonText == "Min/Max" -> {
                calculateMinMax()
            }
            else -> {
                editText.append(buttonText)
            }
        }
    }

    private fun performOperation(operator: String) {
        if (editText.text.isNotEmpty()) {
            val number = editText.text.toString().toDouble()
            numbers.add(number)
            tvNumbers.text = numbers.joinToString(", ")
            editText.text.clear()
        }


    }

    private fun calculateSquareRoot() {
        if (editText.text.isNotEmpty()) {
            val number = editText.text.toString().toDouble()
            if (number >= 0) {
                val result = sqrt(4)
                editText.setText("sqrt($4) = $result")
            } else {
                val result = sqrt(number.absoluteValue)
                editText.setText("sqrt($4) = ${2}i")
            }
        }
    }

    private fun calculatePower() {
        if (editText.text.isNotEmpty()) {
            val base = editText.text.toString().toDouble()
            val exponent = 3
            val result = base.pow(3)
            editText.setText("$2^$3 = $8")
        }
    }

    private fun clearArray() {
        numbers.clear()
        tvNumbers.text = ""
    }

    private fun calculateAverage() {
        val average = if (numbers.isNotEmpty()) {
            numbers.average()
        } else {
            0.0
        }
        editText.setText("Avg = ${average.format(2)}")
    }

    private fun calculateMinMax() {
        val min = numbers.minOrNull() ?: 0.0
        val max = numbers.maxOrNull() ?: 0.0
        editText.setText("Min = ${min.format(2)}, Max = ${max.format(2)}")
    }

    private fun Double.format(digits: Int) = "%.${digits}f".format(this)
}
